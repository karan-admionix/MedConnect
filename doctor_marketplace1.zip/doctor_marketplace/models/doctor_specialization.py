# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class DoctorSpecialization(models.Model):
    _name = 'doctor.specialization'
    _description = 'Doctor Specialization'
    _order = 'sequence, name'

    name = fields.Char(
        string='Specialization',
        required=True,
        translate=True,
    )
    code = fields.Char(
        string='Code',
        help='Short code for the specialization',
    )
    sequence = fields.Integer(
        string='Sequence',
        default=10,
    )
    description = fields.Text(
        string='Description',
    )
    icon = fields.Char(
        string='Icon Class',
        default='fa-stethoscope',
        help='Font Awesome icon class (e.g., fa-heart, fa-brain)',
    )
    image = fields.Binary(
        string='Image',
        attachment=True,
    )
    
    # Parent-Child relationship for sub-specializations
    parent_id = fields.Many2one(
        'doctor.specialization',
        string='Parent Specialization',
        ondelete='cascade',
    )
    child_ids = fields.One2many(
        'doctor.specialization',
        'parent_id',
        string='Sub-specializations',
    )
    
    # Statistics (will be computed when doctor model exists)
    # doctor_count = fields.Integer(
    #     compute='_compute_doctor_count',
    #     string='Number of Doctors',
    # )
    
    # Status
    active = fields.Boolean(
        string='Active',
        default=True,
    )
    featured = fields.Boolean(
        string='Featured',
        default=False,
        help='Show on homepage',
    )
    
    # Color for kanban view
    color = fields.Integer(
        string='Color Index',
    )

    # SQL Constraints
    _sql_constraints = [
        (
            'code_unique',
            'UNIQUE(code)',
            'Specialization code must be unique!'
        ),
    ]

    def name_get(self):
        """Display full hierarchy path for sub-specializations."""
        result = []
        for record in self:
            if record.parent_id:
                name = f"{record.parent_id.name} / {record.name}"
            else:
                name = record.name
            result.append((record.id, name))
        return result
