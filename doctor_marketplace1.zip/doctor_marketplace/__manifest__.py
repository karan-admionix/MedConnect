# -*- coding: utf-8 -*-
{
    'name': 'Doctor Marketplace - Enterprise Edition',
    'version': '19.0.1.0.0',
    'category': 'Healthcare',
    'summary': 'Complete Healthcare Ecosystem with Advanced Features',
    'description': """
        Doctor Marketplace Enterprise Edition
        ======================================
        
        A comprehensive healthcare platform built for Odoo 19 Enterprise.
        
        Phase 1 Features:
        -----------------
        * Doctor registration and verification
        * Patient management with family accounts
        * Appointment booking system
        * Smart waitlist with auto-booking
        * No-show prediction and prevention
        * Review and rating system
        * Doctor earnings and payouts
        
        Phase 2 Features:
        -----------------
        * Patient subscription plans
        * Dynamic pricing engine
        * Health records vault (PHR)
        * Doctor badges and trust levels
        
        Phase 3 Features:
        -----------------
        * Corporate/B2B health programs
        * Dispute resolution system
        * Doctor referral network
        * Advanced review analytics
        
        Phase 4 Features:
        -----------------
        * Platform analytics dashboard
        * Revenue reporting
        * Predictive insights
        * Performance tracking
    """,
    'author': 'ADX Medicare',
    'website': 'https://admionixsolutions.com',
    'license': 'OEEL-1',
    
    'depends': [
        'base',
        'mail',
        'portal',
        'website',
        'payment',
    ],
    
    'data': [
        # Security
        'security/doctor_security.xml',
        'security/ir.model.access.csv',
        
        # Views
        'views/doctor_specialization_views.xml',
        'views/doctor_menus.xml',
        
        # Data (will be added progressively)
    ],
    
    'assets': {
        'web.assets_frontend': [
            # Will be added later
        ],
        'web.assets_backend': [
            # Will be added later
        ],
    },
    
    'installable': True,
    'application': True,
    'auto_install': False,
}
