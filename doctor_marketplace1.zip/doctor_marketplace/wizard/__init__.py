# -*- coding: utf-8 -*-

# Wizards will be imported here as they are created
# from . import doctor_approval_wizard
# etc.
