# -*- coding: utf-8 -*-
{
    'name': 'MedConnect',
    'version': '19.0.2.0.0',
    'category': 'Healthcare',
    'summary': 'Complete Healthcare Ecosystem with Advanced Features',
    'description': """
MedConnect Enterprise Edition
======================================

A comprehensive healthcare platform built for Odoo 19 Enterprise.

PHASE 1 - FOUNDATION:
---------------------
* Doctor registration and verification workflow
* Patient management with family accounts
* Appointment booking system
* Smart waitlist with auto-booking
* No-show prediction and prevention
* Review and rating system
* Doctor earnings and payouts
* Schedule management

PHASE 2 - GROWTH:
-----------------
* Patient subscription plans (Free/Basic/Premium)
* Dynamic pricing engine
* Health records vault (PHR)
* Doctor badges and trust levels
* Premium features
    """,
    'author': 'ADX Medicare',
    'website': 'https://www.adxmedicare.com',
    'license': 'OEEL-1',

    'depends': [
        'base',
        'mail',
        'portal',
        'website',
        'payment',
    ],

    'data': [
        # Security
        'security/doctor_security.xml',
        'security/ir.model.access.csv',

        # Data
        'data/ir_sequence_data.xml',
        'data/doctor_specialization_data.xml',
        'data/subscription_plan_data.xml',
        'data/doctor_badge_data.xml',

        # Views - Configuration
        'views/doctor_specialization_views.xml',
        'views/doctor_consultation_type_views.xml',
        'views/subscription_plan_views.xml',
        'views/doctor_badge_views.xml',

        # Views - Main
        'views/doctor_doctor_views.xml',
        'views/doctor_patient_views.xml',
        'views/doctor_appointment_views.xml',
        'views/doctor_schedule_views.xml',
        'views/doctor_review_views.xml',
        'views/doctor_earning_views.xml',
        'views/doctor_payout_views.xml',
        'views/doctor_waitlist_views.xml',
        'views/health_record_views.xml',
        'views/patient_subscription_views.xml',

        # Menus
        'views/doctor_menus.xml',
    ],

    'assets': {
        'web.assets_backend': [
            'doctor_marketplace/static/src/css/doctor_marketplace.css',
        ],
    },

    'installable': True,
    'application': True,
    'auto_install': False,
}
