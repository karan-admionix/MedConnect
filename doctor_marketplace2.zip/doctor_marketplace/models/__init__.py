# -*- coding: utf-8 -*-

from . import doctor_specialization
from . import doctor_consultation_type
from . import doctor_document
from . import doctor_doctor
from . import doctor_schedule
from . import doctor_patient
from . import family_member
from . import doctor_appointment
from . import doctor_review
from . import doctor_earning
from . import doctor_payout
from . import doctor_waitlist
from . import subscription_plan
from . import patient_subscription
from . import dynamic_pricing
from . import health_record
from . import doctor_badge
